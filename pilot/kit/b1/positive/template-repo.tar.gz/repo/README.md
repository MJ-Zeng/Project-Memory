b1 verifier fixture
