print("1 passed")
